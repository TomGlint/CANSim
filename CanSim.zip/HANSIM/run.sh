#dependencies
# gcc
# g++
# flex
# bison

#make distclean
make -j8

./ANSim example/4x4MeshAsync
