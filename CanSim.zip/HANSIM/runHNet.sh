#simulator executable
sim=./ANSim

#result folder
resultFolder="Results"

experimentName=${1}

#number of paralleljobs
parallelJobs="60"


# #parsec
# parsecPrograms="blackscholes_64c_simmedium bodytrack_64c_simlarge canneal_64c_simmedium dedup_64c_simmedium ferret_64c_simmedium fluidanimate_64c_simsmall swaptions_64c_simlarge vips_64c_simmedium x264_64c_simsmall"

# #location,limit,scale,region,enforcedep,enforcelat,sizeoffset
# parsecLocation="/home/glint/WS/PAR64/"

# Traffics="neighbor uniform transpose tornado shuffle bitrev bitcomp"

# simConfigBaseFolder="ANSIM"

# superOverRide="num_vcs=2 doGating=1 sample_period=30000000"


# #************************************************************************************
# subExperimentName="RoutingSensitivityParsec"

# routingfns="dor xy_yx adaptive_xy_yx romm min_adapt planar_adapt"

# simConfigs="64AMeshBurst"

# for simConfig in $simConfigs
# do
# 	for parsecProgram in $parsecPrograms
# 	do
	
# 		for routingfn in ${routingfns}
# 		do
	
# 			mkdir -p ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${parsecProgram}/${routingfn}
# 			workload="workload=netrace({${parsecLocation}${parsecProgram}.tra.bz2,1000000000,1,2,1,1,0)"
# 			while (( (( $(jobs -p | wc -l) )) >= ${parallelJobs} )) 
# 			 do 
# 				sleep 5      # check again after 5 seconds
# 			 done
			 
# 				jobs -x ${sim} ${simConfigBaseFolder}/${simConfig} ${workload} ${superOverRide} routing_function=${routingfn} | tee ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${parsecProgram}/${routingfn}result.txt &
# 		done
# 	done
# done



# wait
# echo "Finsihed"





simConfigBaseFolder="example/Workload"
networkLocation="/home/glint/WS/Sim/ANSimH2/example/Workload"
Traffics="uniform nonuniform"
#Traffics="nonuniform"
#simConfigs="100HAA 100HAA2 100HAS 100HAS2 100HBA 100HBA2 100HBS 100HBS2 100P 100P2 400HAA 400HAS 400HBA 400HBS 400P"
simConfigs="100AA 400AA"

injectionRates="0.000001 0.000032 0.000063 0.000095 0.00012595 0.000157188 0.000188425 0.000219663 0.0002509 0.000282138 0.000313375 0.000344613 0.00037585 0.000407088 0.000438325 0.000469563 0.0005008 0.000532038 0.000563275 0.000594513 0.00062575 0.000656988 0.000688225 0.000719463 0.0007507 0.000781938 0.000813175 0.000844413 0.00087565 0.000906888 0.000938125 0.000969363 0.0010006 0.001031838 0.001063075 0.001094313 0.00112555 0.001156788 0.001188025 0.001219263 0.0012505 0.001281738 0.001312975 0.001344213 0.00137545 0.001406688 0.001437925 0.001469163 0.0015004 0.001531638 0.001562875 0.001594113 0.00162535 0.001656588 0.001687825 0.001719063 0.0017503 0.001781538 0.001812775 0.001844013 0.00187525 0.001906488 0.001937725 0.001968963 0.0020002 0.002031438 0.002062675 0.002093913 0.00212515 0.002156388 0.002187625 0.002218863 0.0022501 0.002281338 0.002312575 0.002343813 0.00237505 0.002406288 0.002437525 0.002468763 0.0025"
#injectionRates="0.00001"
subExperimentName="HNet"

for simConfig in $simConfigs
do
    for traffic in $Traffics
    do
        for injection in $injectionRates
        do
            mkdir -p ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${traffic}/${injection}

            networkfile=${networkLocation}/${simConfig}copy
            while (( (( $(jobs -p | wc -l) )) >= ${parallelJobs} )) 
			 do 
				sleep 5      # check again after 5 seconds
			 done
             jobs -x ${sim} ${simConfigBaseFolder}/${simConfig} traffic=${traffic} injection_rate=${injection} network_file=${networkfile} | tee ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${traffic}/${injection}/result.txt &


        done
    done
done

wait
echo "Finsihed"