sim=./ANSim

#result folder
resultFolder="Results"

experimentName=${1}

#number of paralleljobs
parallelJobs="42"

simConfigBaseFolder="example/TCAD"
networkLocation="/home/glint/WS/Sim/ANSimH2/example/Workload"





subExperimentName="AMD1GHz"
Traffics="uniform"
simConfigs="8x8MeshSync"
injectionRates="0.000025 0.00005 0.000075 0.0001 0.000125 0.00015 0.000175 0.0002 0.000225 0.00025 0.000275 0.0003 0.000325 0.00035 0.000375 0.0004 0.000425 0.00045 0.000475 0.0005 0.000525 0.00055 0.000575 0.0006 0.000625 0.00065 0.000675 0.0007 0.000725 0.00075 0.000775 0.0008 0.000825 0.00085 0.000875 0.0009 0.000925 0.00095 0.000975 0.001"


for simConfig in $simConfigs
do
    for traffic in $Traffics
    do
        for injection in $injectionRates
        do
            mkdir -p ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${traffic}/${injection}

            #networkfile=${networkLocation}/${simConfig}copy
            while (( (( $(jobs -p | wc -l) )) >= ${parallelJobs} )) 
			 do 
				sleep 5      # check again after 5 seconds
			 done
             jobs -x ${sim} ${simConfigBaseFolder}/${simConfig} traffic=${traffic} injection_rate=${injection} | tee ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${traffic}/${injection}/result.txt &


        done
    done
done

wait
echo "Finsihed"