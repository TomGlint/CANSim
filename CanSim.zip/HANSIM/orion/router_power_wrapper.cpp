#include "router_power.c"
