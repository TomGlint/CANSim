// $Id$

#ifndef _MISC_UTILS_HPP_
#define _MISC_UTILS_HPP_

long long int log_two(long long int x);
long long int powi(long long int x, long long int y);

#endif
