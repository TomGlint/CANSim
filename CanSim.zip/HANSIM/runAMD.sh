sim=./ANSim

#result folder
resultFolder="Results"

experimentName=${1}

#number of paralleljobs
parallelJobs="14"

simConfigBaseFolder="example/"
networkLocation="/home/glint/WS/Sim/ANSimH2/example/Workload"
Traffics="uniform"
simConfigs="4x4MeshAsync 4x4MeshSync"

injectionRates="0.0001 0.0002 0.0003 0.0004 0.0005 0.0006 0.0007 0.0008 0.0009 0.001"
subExperimentName="AMD4x4"

for simConfig in $simConfigs
do
    for traffic in $Traffics
    do
        for injection in $injectionRates
        do
            mkdir -p ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${traffic}/${injection}

            #networkfile=${networkLocation}/${simConfig}copy
            while (( (( $(jobs -p | wc -l) )) >= ${parallelJobs} )) 
			 do 
				sleep 5      # check again after 5 seconds
			 done
             jobs -x ${sim} ${simConfigBaseFolder}/${simConfig} traffic=${traffic} injection_rate=${injection} | tee ${resultFolder}/${experimentName}/${subExperimentName}/${simConfig}/${traffic}/${injection}/result.txt &


        done
    done
done

wait
echo "Finsihed"