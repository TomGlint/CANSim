// $Id$

#define main rng_main
#include "rng.c"

long ran_next()
{
  return ran_arr_next();
}
